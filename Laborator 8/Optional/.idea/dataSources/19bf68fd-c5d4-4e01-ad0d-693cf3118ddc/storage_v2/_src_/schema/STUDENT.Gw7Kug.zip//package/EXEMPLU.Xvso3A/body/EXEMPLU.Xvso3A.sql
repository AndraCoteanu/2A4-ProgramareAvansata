create PACKAGE BODY exemplu IS

--numele si banii calatorilor
PROCEDURE youngest is
    v_nume   varchar2(30);
    v_varsta number;
BEGIN
    select nume, varsta into v_nume, v_varsta from (select nume, varsta from CALATORI order by varsta) where rownum = 1;
END;

--cati bani are cel mai bogat
PROCEDURE richest(p_id_excursie IN number) is
    v_suma number;
BEGIN
    select max(c.buget_excursii)
    into v_suma
    from CALATORI c,
         VACANTA v
    where v.id_excursie = p_id_excursie
      and v.id_calator = c.CNP;
    DBMS_OUTPUT.PUT_LINE(v_suma);
END;

-- cate excursii poate organiza un organizator
FUNCTION nr_organizari(p_cnp number)
    RETURN number
is
    v_nr_excursii number(2) := 0;
begin
    select count(id_excursie) into v_nr_excursii from ORGANIZATORI where id_organizator = p_cnp;
    return v_nr_excursii;
end;

--cate locuri mai sunt
FUNCTION nr_locuri_libere(p_id_excursie number)
    RETURN number
is
    v_nr_locuri_libere number(3) := 0;
begin
    select locuri_disponbile - locuri_ocupate into v_nr_locuri_libere from EXCURSII where id_excursie = p_id_excursie;
    return v_nr_locuri_libere;
end;

END exemplu;
/

