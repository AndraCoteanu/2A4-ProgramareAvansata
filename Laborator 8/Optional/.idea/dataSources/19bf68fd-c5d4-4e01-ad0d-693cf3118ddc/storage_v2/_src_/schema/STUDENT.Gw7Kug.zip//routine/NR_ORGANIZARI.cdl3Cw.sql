create FUNCTION nr_organizari(p_cnp number)
    RETURN number
is
    v_nr_excursii number(2) := 0;
begin
    select count(id_excursie) into v_nr_excursii from ORGANIZATORI where id_organizator = p_cnp;
    return v_nr_excursii;
end;
/

