create PACKAGE BODY VACANTE IS

        --numele si banii calatorilor
    PROCEDURE youngest is
        v_nume   varchar2(30);
        v_varsta number;
    BEGIN
        select nume, varsta
        into v_nume, v_varsta
        from (select nume, varsta from CALATORI order by varsta)
        where rownum = 1;
    END;

--cati bani are cel mai bogat
    PROCEDURE richest(p_id_excursie IN number) is
        v_suma number;
    BEGIN
        select max(c.buget_excursii)
        into v_suma
        from CALATORI c,
             VACANTA v
        where v.id_excursie = p_id_excursie
          and v.id_calator = c.CNP;
        DBMS_OUTPUT.PUT_LINE(v_suma);
    END;

-- cate excursii poate organiza un organizator
    FUNCTION nr_organizari(p_cnp number)
        RETURN number
        is
        v_nr_excursii number(2) := 0;
    begin
        select count(id_excursie) into v_nr_excursii from ORGANIZATORI where id_organizator = p_cnp;
        return v_nr_excursii;
    end;

--cate locuri mai sunt
    FUNCTION nr_locuri_libere(p_id_excursie number)
        RETURN number
        is
        v_nr_locuri_libere number(3) := 0;
    begin
        select locuri_disponbile - locuri_ocupate
        into v_nr_locuri_libere
        from EXCURSII
        where id_excursie = p_id_excursie;
        return v_nr_locuri_libere;
    end;

--cati bani mai sunt?
FUNCTION money_left(p_cnp number)
    RETURN number
is
    v_buget      number(6);
    v_cheltuiala number(7);
BEGIN
    SELECT buget_excursii into v_buget from CALATORI where CNP = p_cnp;
    select SUM(E.pret)
    into v_cheltuiala
    from EXCURSII E,
         CALATORI C,
         VACANTA V
    where E.ID_EXCURSIE = V.ID_EXCURSIE
      and V.id_calator = C.CNP
      and C.CNP = p_cnp
    group by c.CNP;
    RETURN v_buget - v_cheltuiala;
end;


--care este genul?
FUNCTION what_it_is(p_cnp number)
    RETURN VARCHAR2
AS
    v_baiat varchar2(10) := 'baiat';
    v_fata  varchar2(10) := 'fata';
    v_last  number       := p_cnp;
BEGIN
    DBMS_OUTPUT.PUT_LINE(v_last);
    v_last := floor(v_last / 1000000000000);
    DBMS_OUTPUT.PUT_LINE(v_last);
    if (v_last = 1 or v_last = 5) then
        return v_baiat;
    else
        return v_fata;
    end if;
end;



-- care este CNP
FUNCTION get_CNP(p_nume varchar2, p_prenume varchar2)
    RETURN NUMBER
AS
    v_cnp number(13);
BEGIN
    SELECT CNP into v_cnp FROM CALATORI where nume = p_nume AND prenume = p_prenume;
    return v_cnp;
end;



--varsta per excursie
FUNCTION avg_age(p_id_excursie number)
    RETURN number
AS
    v_avg_age number;
BEGIN
    SELECT avg(c.varsta)
    into v_avg_age
    from CALATORI c,
         VACANTA v,
         EXCURSII e
    where e.ID_EXCURSIE = v.id_excursie
      and c.CNP = v.id_calator
      and v.id_excursie = p_id_excursie
    group by e.id_excursie;
    return v_avg_age;
end;


--zile in excursie
FUNCTION nr_days(p_cnp number)
    RETURN number
as
    v_nr_days number(3) := 0;
begin
    select sum(e.numar_zile)
    into v_nr_days
    from CALATORI c,
         VACANTA v,
         EXCURSII e
    where e.ID_EXCURSIE = v.id_excursie
      and c.CNP = v.id_calator
      and c.CNP = p_cnp;
    return v_nr_days;
end;


-- numar de excursii

FUNCTION nr_excursii(p_cnp number)
    RETURN number
as
    v_nr_excursii number(2) := 0;
begin
    select count(id_excursie) into v_nr_excursii from VACANTA where id_calator = p_cnp;
    return v_nr_excursii;
end;

END;
/

