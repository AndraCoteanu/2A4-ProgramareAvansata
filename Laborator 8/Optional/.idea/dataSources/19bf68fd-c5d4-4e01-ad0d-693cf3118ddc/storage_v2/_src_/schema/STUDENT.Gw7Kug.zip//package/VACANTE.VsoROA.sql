create PACKAGE VACANTE IS
    PROCEDURE richest(p_id_excursie IN number);
    PROCEDURE youngest;
    FUNCTION nr_organizari(p_cnp number) RETURN number;
    FUNCTION nr_locuri_libere(p_id_excursie number) RETURN number;
    FUNCTION money_left(p_cnp number) RETURN number;
    FUNCTION what_it_is(p_cnp number) RETURN VARCHAR2;
    FUNCTION get_CNP(p_nume varchar2, p_prenume varchar2) RETURN NUMBER;
    FUNCTION avg_age(p_id_excursie number) RETURN number;
    FUNCTION nr_days(p_cnp number) RETURN number;
    FUNCTION nr_excursii(p_cnp number) RETURN number;
END VACANTE;
/

