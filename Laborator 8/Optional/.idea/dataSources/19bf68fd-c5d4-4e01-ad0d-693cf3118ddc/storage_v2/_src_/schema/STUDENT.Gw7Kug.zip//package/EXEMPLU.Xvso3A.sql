create PACKAGE exemplu IS
    PROCEDURE richest(p_id_excursie IN number);
    PROCEDURE youngest;
    FUNCTION nr_organizari(p_cnp number) RETURN number;
    FUNCTION nr_locuri_libere(p_id_excursie number) RETURN number;

END exemplu;
/

