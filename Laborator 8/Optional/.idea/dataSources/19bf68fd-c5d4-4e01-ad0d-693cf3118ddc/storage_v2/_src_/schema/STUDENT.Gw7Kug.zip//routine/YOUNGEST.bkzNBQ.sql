create PROCEDURE youngest is
    v_nume   varchar2(30);
    v_varsta number;
BEGIN
    select nume, varsta into v_nume, v_varsta from (select nume, varsta from CALATORI order by varsta) where rownum = 1;
END;
/

