create PROCEDURE richest(p_id_excursie IN number) is
    v_suma number;
BEGIN
    select max(c.buget_excursii)
    into v_suma
    from CALATORI c,
         VACANTA v
    where v.id_excursie = p_id_excursie
      and v.id_calator = c.CNP;
    DBMS_OUTPUT.PUT_LINE(v_suma);
END;
/

