create FUNCTION nr_locuri_libere(p_id_excursie number)
    RETURN number
is
    v_nr_locuri_libere number(3) := 0;
begin
    select locuri_disponbile - locuri_ocupate into v_nr_locuri_libere from EXCURSII where id_excursie = p_id_excursie;
    return v_nr_locuri_libere;
end;
/

